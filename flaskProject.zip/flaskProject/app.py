from flask import Flask, render_template
from flask import render_template
#return render_template('home.html')

app = Flask(__name__)
#return render_template('templates/home.html')
@app.route('/')
def home():
     return render_template('home.html')
     #return "Hello, Flask!"

@app.route('/about')
def about():
     return render_template('about.html')


if __name__ == '__main__':
    app.run(debug=True)    