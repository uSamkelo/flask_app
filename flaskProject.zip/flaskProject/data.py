def Articles():
 articles = [
 {
 'uid': 1,
 'title': 'Article_One',
 'body': 'Flask, being a microframework, often requires some repetitive steps to get a third party library working. Because very often these  steps could be abstracted to support multiple projects the Flask Extension Registry was created.',
 'Author': 'Rajesh Joshi',
 'Created-on': '07-09-2018'
 },
 {
 'uid': 2,
 'title': 'Article_Two',
 'body': "Flask, being a microframework, often requires some repetitive steps to get a third party library working. Because very often these steps could be abstracted to support multiple projects the Flask Extension Registry was created.",
 'Author': 'Rajesh J',
 'Created-on': '07-09-2018'
 },
 {
 'uid': 3,
 'title': 'Article_Three',
 'body': 'Flask, being a microframework, often requires some repetitive steps to get a third party library working. Because very often these steps could be abstracted to support multiple projects the Flask Extension Registry was created.',
 'Author': 'Joshi Rajesh',
 'Created-on': '07-09-2018'
 }
 ]
 return articles